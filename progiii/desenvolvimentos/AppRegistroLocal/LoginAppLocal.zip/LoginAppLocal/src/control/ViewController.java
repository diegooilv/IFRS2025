/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.Dimension;
import java.util.Arrays;
import java.util.List;
import javax.swing.JDesktopPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import model.Pessoa;
import model.PessoaDAO;
import view.ViewProfile;

/**
 *
 * @author Diego
 */
public class ViewController {

    private List<Pessoa> lista;

    private JDesktopPane jDesktopPane;
    private JPanel jPanelPrincipal;
    private JPanel jPanelLogin;
    private JPanel jPanelRegistrar;
    private JTextField jTextFieldNomeRegistrar;
    private JTextField jTextFieldEmailRegistrar;
    private JPasswordField jPasswordFieldSenhaRegistrar;
    private JTextField jTextFieldEmailLogin;
    private JPasswordField jPasswordFieldSenhaLogin;

    public ViewController(JDesktopPane jDesktopPane, JPanel jPanelPrincipal, JPanel jPanelLogin, JPanel jPanelRegistrar, JTextField jTextFieldNomeRegistrar, JTextField jTextFieldEmailRegistrar, JPasswordField jPasswordFieldSenhaRegistrar, JTextField jTextFieldEmailLogin, JPasswordField jPasswordFieldSenhaLogin) {
        this.jDesktopPane = jDesktopPane;
        this.jPanelPrincipal = jPanelPrincipal;
        this.jPanelLogin = jPanelLogin;
        this.jPanelRegistrar = jPanelRegistrar;
        this.jTextFieldNomeRegistrar = jTextFieldNomeRegistrar;
        this.jTextFieldEmailRegistrar = jTextFieldEmailRegistrar;
        this.jPasswordFieldSenhaRegistrar = jPasswordFieldSenhaRegistrar;
        this.jTextFieldEmailLogin = jTextFieldEmailLogin;
        this.jPasswordFieldSenhaLogin = jPasswordFieldSenhaLogin;
        lista = PessoaDAO.carregarLista();
    }

// lista = PessoaDAO.carregarLista();
    private void adicionarPessoa(String nome, String email, char[] senha) {
        Pessoa p = new Pessoa(nome, email, senha);
        lista.add(p);
        PessoaDAO.salvarLista(lista);
    }

    public List<Pessoa> listarPessoas() {
        return lista;
    }

    public void butaoRegistrar() {
        String nome = jTextFieldNomeRegistrar.getText();
        String email = jTextFieldEmailRegistrar.getText();
        char[] senha = jPasswordFieldSenhaRegistrar.getPassword();
        adicionarPessoa(nome, email, senha);
        lista = PessoaDAO.carregarLista();

        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jPanelPrincipal.getSize();
        ViewProfile view = new ViewProfile(nome, email, senha);
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        jPanelLogin.setVisible(false);
        jPanelRegistrar.setVisible(false);
        view.setVisible(true);
    }

    public void butaoLogin() {
        String email = jTextFieldEmailLogin.getText();
        for (Pessoa a : lista) {
            if (a.getEmail().equals(email)) {
                char[] senha = jPasswordFieldSenhaLogin.getPassword();
                if (Arrays.equals(a.getSenha(), senha)) {
                    jDesktopPane.removeAll();
                    jDesktopPane.updateUI();
                    Dimension size = jPanelPrincipal.getSize();
                    ViewProfile view = new ViewProfile(a.getNome(), a.getEmail(), a.getSenha());
                    view.setSize(size);
                    view.setLocation(0, 0);
                    jDesktopPane.add(view);
                    jPanelLogin.setVisible(false);
                    jPanelRegistrar.setVisible(false);
                    view.setVisible(true);
                }

            }
        }
    }
}
