/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import javax.swing.JLabel;

/**
 *
 * @author Diego
 */
public class ViewProfileController {

    private JLabel jLabelNome;
    private JLabel jLabelEmail;
    private JLabel jLabelSenha;
    private String nome;
    private String email;
    private char[] senha;

    public ViewProfileController(JLabel jLabelNome, JLabel jLabelEmail, JLabel jLabelSenha, String nome, String email, char[] senha) {
        this.jLabelNome = jLabelNome;
        this.jLabelEmail = jLabelEmail;
        this.jLabelSenha = jLabelSenha;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        init();
    }

    private void init() {
        jLabelNome.setText(nome);
        jLabelEmail.setText(email);
        jLabelSenha.setText(String.valueOf(senha));
    }

    public void fechar() {

    }
}
