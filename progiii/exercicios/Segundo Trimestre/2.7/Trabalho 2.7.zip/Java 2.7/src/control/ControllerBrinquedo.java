/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Brinquedo;

/**
 *
 * @author Diego
 */
public class ControllerBrinquedo {

    private List<Brinquedo> listBrinquedos;
    private List<String> listStrings;
    private Brinquedo brinquedo;
    private Brinquedo brinquedoEditado;
    //
    private JTextField jTextFieldId;
    private JTextField jTextFieldNome;
    private JTextField jTextFieldValor;
    private JComboBox jComboBox;
    private JList<String> jList;
    private DefaultListModel defaultListModel;//

    private JButton butao;

    public ControllerBrinquedo(JTextField jTextFieldId, JTextField jTextFieldNome, JTextField jTextFieldValor, JComboBox jComboBox, JList<String> jList, JButton butao) {
        this.jTextFieldId = jTextFieldId;
        this.jTextFieldNome = jTextFieldNome;
        this.jTextFieldValor = jTextFieldValor;
        this.jComboBox = jComboBox;
        this.jList = jList;
        this.butao = butao;
        this.jTextFieldId.setEditable(false);

        listBrinquedos = new ArrayList<>();
        listStrings = new ArrayList<>();
        defaultListModel = new DefaultListModel();

        limpar();

    }

    public void butao() {
        if (butao.getText().equals("Criar")) {
            novoBrinquedo();
            carregarJlist();
            limpar();
        } else {
            salvarBrinquedo();
            carregarJlist();
            butao.setText("Criar");
            limpar();
        }
    }

    private int gerarId() {
        return listBrinquedos.isEmpty() ? 1 : listBrinquedos.getLast().getId() + 1;
    }

    private void limpar() {
        jTextFieldId.setText(String.valueOf(gerarId()));
        jTextFieldNome.setText("");
        jTextFieldValor.setText("");
        jComboBox.setSelectedIndex(0);
    }

    private void novoBrinquedo() {
        brinquedo = new Brinquedo(
                Integer.parseInt(jTextFieldId.getText()),
                jTextFieldNome.getText(),
                Double.parseDouble(jTextFieldValor.getText()),
                (String) jComboBox.getSelectedItem()
        );

        listBrinquedos.add(brinquedo);
    }

    // string text = b.getNome() + " Valor: " + b.getValor();
    public void butaoDoJlist() {
        String text = jList.getSelectedValue();
        if (text == null || text.isEmpty()) {
            return;
        }

        for (Brinquedo b : listBrinquedos) {
            String text2 = b.getNome() + " Valor: " + b.getValor();
            if (text.equals(text2)) {
                brinquedoEditado = b;  // Corrigido
                jTextFieldId.setText(String.valueOf(brinquedoEditado.getId()));
                jTextFieldNome.setText(brinquedoEditado.getNome());
                jTextFieldValor.setText(String.valueOf(brinquedoEditado.getValor()));
                jComboBox.setSelectedItem(brinquedoEditado.getCategoria());
                break;
            }
        }

        butao.setText("Salvar");
    }

    private void salvarBrinquedo() {
        brinquedoEditado.setNome(jTextFieldNome.getText());
        brinquedoEditado.setValor(Double.parseDouble(jTextFieldValor.getText()));
        brinquedoEditado.setCategoria((String) jComboBox.getSelectedItem());
    }

    private void carregarJlist() {
        listStrings.clear();
        defaultListModel.clear();
        String text;
        for (Brinquedo b : listBrinquedos) {
            text = b.getNome() + " Valor: " + b.getValor();
            listStrings.add(text);
        }
        defaultListModel.addAll(listStrings);
        jList.setModel(defaultListModel);
    }
}
