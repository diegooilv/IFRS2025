/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.Dimension;
import javax.swing.JDesktopPane;
import view.Brinquedo;
import view.Comida;

/**
 *
 * @author Diego
 */
public class ControllerTela {

    private JDesktopPane jDesktopPane;

    public ControllerTela(JDesktopPane jDesktopPane) {
        this.jDesktopPane = jDesktopPane;
    }

    public void brinquedo() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        Brinquedo view = new Brinquedo();
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        view.setVisible(true);
    }

    public void comida() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        Comida view = new Comida();
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        view.setVisible(true);
    }
}
