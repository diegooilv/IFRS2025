package control;

import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Comida;

public class ControllerComida {

    private List<Comida> listComidas;
    private List<String> listStrings;
    private Comida comida;
    private Comida comidaEditada;

    private JTextField jTextFieldId;
    private JTextField jTextFieldNome;
    private JTextField jTextFieldDesc;
    private JTextField jTextFieldValor;
    private JList<String> jList;
    private DefaultListModel<String> defaultListModel;
    private JButton botao;

    public ControllerComida(JTextField jTextFieldId, JTextField jTextFieldNome, JTextField jTextFieldDesc, JTextField jTextFieldValor, JList<String> jList, JButton botao) {
        this.jTextFieldId = jTextFieldId;
        this.jTextFieldNome = jTextFieldNome;
        this.jTextFieldDesc = jTextFieldDesc;
        this.jTextFieldValor = jTextFieldValor;
        this.jList = jList;
        this.botao = botao;

        this.jTextFieldId.setEditable(false);

        listComidas = new ArrayList<>();
        listStrings = new ArrayList<>();
        defaultListModel = new DefaultListModel<>();

        limpar();
    }

    public void botaoAcao() {
        if (botao.getText().equals("Criar")) {
            novoComida();
            carregarJList();
            limpar();
        } else {
            salvarComida();
            carregarJList();
            botao.setText("Criar");
            limpar();
        }
    }

    private int gerarId() {
        return listComidas.isEmpty() ? 1 : listComidas.get(listComidas.size() - 1).getId() + 1;
    }

    private void limpar() {
        jTextFieldId.setText(String.valueOf(gerarId()));
        jTextFieldNome.setText("");
        jTextFieldDesc.setText("");
        jTextFieldValor.setText("");
    }

    private void novoComida() {
        comida = new Comida(
                Integer.parseInt(jTextFieldId.getText()),
                jTextFieldNome.getText(),
                jTextFieldDesc.getText(),
                Double.parseDouble(jTextFieldValor.getText())
        );

        listComidas.add(comida);
    }

    public void botaoDoJList() {
        String textoSelecionado = jList.getSelectedValue();
        if (textoSelecionado == null || textoSelecionado.isEmpty()) {
            return;
        }

        for (Comida c : listComidas) {
            String texto = c.getNome() + " - " + c.getDesc() + " : " + c.getValor();
            if (textoSelecionado.equals(texto)) {
                comidaEditada = c;
                jTextFieldId.setText(String.valueOf(comidaEditada.getId()));
                jTextFieldNome.setText(comidaEditada.getNome());
                jTextFieldDesc.setText(comidaEditada.getDesc());
                jTextFieldValor.setText(String.valueOf(comidaEditada.getValor()));
                break;
            }
        }

        botao.setText("Salvar");
    }

    private void salvarComida() {
        comidaEditada.setNome(jTextFieldNome.getText());
        comidaEditada.setDesc(jTextFieldDesc.getText());
        comidaEditada.setValor(Double.parseDouble(jTextFieldValor.getText()));
    }

    private void carregarJList() {
        listStrings.clear();
        defaultListModel.clear();

        for (Comida c : listComidas) {
            String texto = c.getNome() + " - " + c.getDesc() + " : " + c.getValor();
            listStrings.add(texto);
        }

        defaultListModel.addAll(listStrings);
        jList.setModel(defaultListModel);
    }
}
