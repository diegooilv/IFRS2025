/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador; // Define o pacote onde essa classe está localizada

// Importação de bibliotecas necessárias
import java.util.ArrayList; // Lista dinâmica que permite adicionar/remover elementos
import java.util.Collections; // Utilizado para ordenar listas
import javax.swing.DefaultListModel; // Modelo padrão usado em listas gráficas (JList)
import javax.swing.JButton; // Representa um botão na interface gráfica
import javax.swing.JList; // Componente gráfico para exibir uma lista de itens
import javax.swing.JTextField; // Campo de texto para entrada de dados
import modelo.Cliente; // Importa a classe Cliente (deve estar na pasta modelo)

/**
 *
 * @author victorperes
 */
public class ControladorCliente {

    // Declaração de variáveis que representam os campos da interface gráfica
    JTextField jTextFieldId; // Campo de texto para o ID do cliente
    JTextField jTextFieldNome; // Campo de texto para o nome do cliente
    JTextField jTextFieldTelefone; // Campo de texto para o telefone do cliente
    JButton jButtonSalvarEditar; // Botão que alterna entre "Salvar" e "Editar"
    JList<String> jListClientes; // Lista gráfica que mostra os nomes dos clientes

    // Lista que armazenará os clientes em memória
    ArrayList<Cliente> listaCliente = new ArrayList<>();

    // Modelo usado pela JList para mostrar os dados
    DefaultListModel defaultListModel = new DefaultListModel();

    // Índice do cliente selecionado (para edição)
    int index;

    // Construtor da classe (inicializa os componentes e limpa os campos)
    public ControladorCliente(JTextField jTextFieldId, JTextField jTextFieldNome, JTextField jTextFieldTelefone, JButton jButtonSalvarEditar, JList<String> jListProjetos) {
        this.jTextFieldId = jTextFieldId;
        this.jTextFieldNome = jTextFieldNome;
        this.jTextFieldTelefone = jTextFieldTelefone;
        this.jButtonSalvarEditar = jButtonSalvarEditar;
        this.jListClientes = jListProjetos;
        limpar(); // Chama o método para limpar os campos
    }

    // Método para limpar os campos da interface gráfica
    public void limpar() {
        jTextFieldNome.setText(""); // Limpa o campo nome
        jTextFieldTelefone.setText(""); // Limpa o campo telefone

        // Gera um novo ID automaticamente e coloca no campo de ID
        jTextFieldId.setText(gerarID() + "");

        // Define o texto do botão como "Salvar"
        jButtonSalvarEditar.setText("Salvar");
    }

    // Método responsável por salvar ou editar um cliente
    public void salvarCliente() {
        // Lê os dados dos campos
        int id = Integer.parseInt(jTextFieldId.getText());
        String nome = jTextFieldNome.getText();
        String telefone = jTextFieldTelefone.getText();

        // Cria um novo objeto cliente com os dados informados
        Cliente c = new Cliente(id, nome, telefone);

        // Verifica se o botão está no modo "Salvar"
        if (jButtonSalvarEditar.getText().compareToIgnoreCase("Salvar") == 0) {
            listaCliente.add(c); // Adiciona o novo cliente à lista
        } else {
            // Se estiver no modo "Editar", atualiza os dados do cliente selecionado
            listaCliente.set(index, c);
        }

        limpar(); // Limpa os campos
        carregarLista(); // Atualiza a lista gráfica
    }

    // Método para carregar os clientes na JList da interface
    public void carregarLista() {
        defaultListModel = new DefaultListModel(); // Cria um novo modelo de lista
        ArrayList<String> listaAtualizada = new ArrayList<>();

        // Para cada cliente, cria uma string com nome e ID e adiciona na lista
        for (Cliente cliente : listaCliente) {
            listaAtualizada.add(cliente.getNome() + " - " + cliente.getId());
        }

        Collections.sort(listaAtualizada); // Ordena a lista alfabeticamente
        defaultListModel.addAll(listaAtualizada); // Adiciona os itens ao modelo
        jListClientes.setModel(defaultListModel); // Define o modelo na JList
    }

    // Método para gerar um novo ID para o cliente
    public int gerarID() {
        int novoID = 1; // ID padrão inicial

        // Se a lista de clientes não está vazia
        if (!listaCliente.isEmpty()) {
            // Pega o último cliente da lista e soma 1 ao seu ID
            novoID = listaCliente.getLast().getId() + 1;
        }

        return novoID; // Retorna o novo ID
    }

    // Método chamado quando um item da lista é selecionado
    public void selecionarObjeto() {
        String clienteselecionado = jListClientes.getSelectedValue(); // Pega o item selecionado
        index = 0; // Inicializa o índice

        // Percorre a lista de clientes
        for (Cliente cliente : listaCliente) {
            String temp = cliente.getNome() + " - " + cliente.getId(); // Monta a string de comparação

            // Se a string bate com a selecionada na lista
            if (temp.compareToIgnoreCase(clienteselecionado) == 0) {
                // Preenche os campos com os dados do cliente
                jTextFieldId.setText(cliente.getId() + "");
                jTextFieldNome.setText(cliente.getNome());
                jTextFieldTelefone.setText(cliente.getTelefone());

                // Muda o botão para "Editar"
                jButtonSalvarEditar.setText("Editar");
                break; // Para o loop
            }

            index++; // Avança para o próximo índice
        }
    }

}
