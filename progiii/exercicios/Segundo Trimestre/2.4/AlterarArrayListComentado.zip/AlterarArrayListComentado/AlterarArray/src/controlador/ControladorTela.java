/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador; // Define o pacote em que essa classe está (controlador)

// Importações necessárias
import java.awt.Dimension; // Usado para trabalhar com dimensões (largura e altura)
import javax.swing.JDesktopPane; // Painel onde janelas internas (JInternalFrames) são abertas
import visao.Tela1; // Importa a tela Tela1 da pasta "visao"

/**
 *
 * @author victorperes
 */
public class ControladorTela {

    // Variável que representa o painel principal onde as janelas internas são exibidas
    JDesktopPane jDesktop;

    // Construtor da classe que recebe o painel da interface gráfica principal
    public ControladorTela(JDesktopPane jDesktop) {
        this.jDesktop = jDesktop; // Armazena o painel na variável da classe
    }

    // Método para abrir a tela Tela1 dentro do painel jDesktop
    public void abrirTela1() {
        jDesktop.removeAll(); // Remove qualquer janela que já esteja aberta no painel
        jDesktop.updateUI(); // Atualiza a interface do painel após a limpeza

        // Captura o tamanho (largura e altura) atual do painel
        Dimension resolucao = jDesktop.getSize();

        // Cria um novo objeto da Tela1 (uma janela interna)
        Tela1 tela1 = new Tela1();

        // Define o tamanho da Tela1 para ocupar todo o espaço do painel
        tela1.setSize(resolucao);

        // Posiciona a Tela1 no canto superior esquerdo (0, 0)
        tela1.setLocation(0, 0);

        // Adiciona a Tela1 ao painel principal
        jDesktop.add(tela1);

        // Torna a Tela1 visível para o usuário
        tela1.setVisible(true);
    }
}
