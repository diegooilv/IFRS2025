/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo; 

/**
 *
 * @author victorperes
 */
public class Cliente {

    // Atributos (ou campos) da classe Cliente
    int id;           // Identificador do cliente (inteiro)
    String nome;      // Nome do cliente
    String telefone;  // Telefone do cliente

    // Construtor da classe Cliente
    // Usado para criar um novo cliente com os dados informados
    public Cliente(int id, String nome, String telefone) {
        this.id = id;               // Atribui o id recebido ao atributo da classe
        this.nome = nome;           // Atribui o nome recebido ao atributo da classe
        this.telefone = telefone;   // Atribui o telefone recebido ao atributo da classe
    }

    // Métodos getters e setters (usados para acessar e alterar os atributos)

    // Retorna o id do cliente
    public int getId() {
        return id;
    }

    // Define um novo id para o cliente
    public void setId(int id) {
        this.id = id;
    }

    // Retorna o nome do cliente
    public String getNome() {
        return nome;
    }

    // Define um novo nome para o cliente
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Retorna o telefone do cliente
    public String getTelefone() {
        return telefone;
    }

    // Define um novo telefone para o cliente
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}
