/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import modelo.Comida;

/**
 *
 * @author Diego
 */
public class DBComida {
    private static final String ARQUIVO = "comida.dat";

    // Carregar lista do arquivo .dat
    public static List<Comida> carregar() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARQUIVO))) {
            return (List<Comida>) ois.readObject();
        } catch (FileNotFoundException e) {
            return new ArrayList<>(); // Se não existir, retorna lista vazia
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // Salvar lista no arquivo .dat
    public static void salvar(List<Comida> comidas) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARQUIVO))) {
            oos.writeObject(comidas);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
