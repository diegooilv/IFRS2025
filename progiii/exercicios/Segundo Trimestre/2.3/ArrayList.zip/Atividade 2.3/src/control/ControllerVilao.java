/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Vilao;

/**
 *
 * @author Diego
 */
public class ControllerVilao {

    private JTextField jTextFieldId;
    private JTextField jTextFieldNome;
    private JTextField jTextFieldPoder;
    private JTextField jTextFieldRegiao;
    private JTextField jTextFieldPerigo;

    private JList jList;
    private DefaultListModel defaultListModel;
    private List<Vilao> listViloes;
    private List<String> listStrings;
    private Vilao vilao;

    public ControllerVilao(JTextField jTextFieldId, JTextField jTextFieldNome,
                           JTextField jTextFieldPoder, JTextField jTextFieldRegiao,
                           JTextField jTextFieldPerigo, JList jList) {
        this.jTextFieldId = jTextFieldId;
        this.jTextFieldNome = jTextFieldNome;
        this.jTextFieldPoder = jTextFieldPoder;
        this.jTextFieldRegiao = jTextFieldRegiao;
        this.jTextFieldPerigo = jTextFieldPerigo;

        this.jList = jList;
        this.defaultListModel = new DefaultListModel();
        this.listViloes = new ArrayList<>();
        this.listStrings = new ArrayList<>();

        this.jList.setModel(defaultListModel);

        limpar();
    }

    private void limpar() {
        jTextFieldId.setText(String.valueOf(gerarId()));
        jTextFieldNome.setText("");
        jTextFieldPoder.setText("");
        jTextFieldRegiao.setText("");
        jTextFieldPerigo.setText("");
    }

    private int gerarId() {
        return listViloes.isEmpty() ? 0 : listViloes.get(listViloes.size() - 1).getId() + 1;
    }

    private void carregarList() {
        defaultListModel.clear();
        listStrings.clear();
        for (Vilao v : listViloes) {
            listStrings.add(v.getId() + " - " + v.getNome() + " " + v.toString());
        }
        defaultListModel.addAll(listStrings);
    }

    public void salvar() {
        vilao = new Vilao(
                Integer.parseInt(jTextFieldId.getText()),
                jTextFieldNome.getText(),
                Integer.parseInt(jTextFieldPoder.getText()),
                jTextFieldRegiao.getText(),
                jTextFieldPerigo.getText()
        );
        listViloes.add(vilao);
        carregarList();
        limpar();
    }
}
