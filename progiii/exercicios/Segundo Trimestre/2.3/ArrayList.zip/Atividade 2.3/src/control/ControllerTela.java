/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.Dimension;
import javax.swing.JDesktopPane;
import view.Heroi;
import view.Vilao;

/**
 *
 * @author Diego
 */
public class ControllerTela {

    private JDesktopPane jDesktopPane;

    public ControllerTela(JDesktopPane jDesktopPane) {
        this.jDesktopPane = jDesktopPane;
    }

    public void heroi() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        Heroi view = new Heroi();
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        view.setVisible(true);
    }
    
    public void vilao() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        Vilao view = new Vilao();
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        view.setVisible(true);
    }

}
