/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Heroi;

/**
 *
 * @author Diego
 */
public class ControllerHeroi {

    private JTextField jTextFieldId;
    private JTextField jTextFieldNome;
    private JTextField jTextFieldIdade;
    private JTextField jTextFieldCidade;
    private JTextField jTextFieldCargo;
    //
    private JList jList;
    private DefaultListModel defaultListModel;
    private List<Heroi> listHerois;
    private List<String> listStrings;
    private Heroi heroi;
    //

    public ControllerHeroi(JTextField jTextFieldId, JTextField jTextFieldNome, JTextField jTextFieldIdade, JTextField jTextFieldCidade, JTextField jTextFieldCargo, JList jList) {
        this.jTextFieldId = jTextFieldId;
        this.jTextFieldNome = jTextFieldNome;
        this.jTextFieldIdade = jTextFieldIdade;
        this.jTextFieldCidade = jTextFieldCidade;
        this.jTextFieldCargo = jTextFieldCargo;
        this.jList = jList;

        listHerois = new ArrayList<>();

        listStrings = new ArrayList<>();

        defaultListModel = new DefaultListModel();

        jTextFieldId.setEditable(false);
        limpar();
    }

    private void limpar() {
        jTextFieldId.setText(String.valueOf(gerarId()));
        jTextFieldCargo.setText("");
        jTextFieldCidade.setText("");
        jTextFieldIdade.setText("");
        jTextFieldNome.setText("");
    }

    private int gerarId() {
        return listHerois.isEmpty() ? 0 : listHerois.getLast().getId() + 1;
    }

    private void carregarList() {
        defaultListModel.clear();
        listStrings.clear();
        for (Heroi h : listHerois) {
            listStrings.add(h.getId() + " - " + h.getNome());
        }
        defaultListModel.addAll(listStrings);
        jList.setModel(defaultListModel);
    }

    public void salvar() {
        heroi = new Heroi(
                Integer.parseInt(jTextFieldId.getText()),
                jTextFieldNome.getText(),
                Integer.parseInt(jTextFieldIdade.getText()),
                jTextFieldCidade.getText(),
                jTextFieldCargo.getText());
        listHerois.add(heroi);
        carregarList();
        limpar();
    }
}
