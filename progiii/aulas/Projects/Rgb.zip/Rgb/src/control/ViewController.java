/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.Dimension;
import javax.swing.JDesktopPane;
import view.ViewBlue;
import view.ViewGreen;
import view.ViewRed;

/**
 *
 * @author Diego
 */
public class ViewController {

    private JDesktopPane jDesktopPane;

    public ViewController(JDesktopPane jDesktopPane) {
        this.jDesktopPane = jDesktopPane;
    }

    public void viewRed() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        ViewRed view = new ViewRed();
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        view.setVisible(true);
    }

    public void viewBlue() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        ViewBlue view = new ViewBlue();
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        view.setVisible(true);
    }

    public void viewGreen() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        ViewGreen view = new ViewGreen();
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        view.setVisible(true);
    }
}
