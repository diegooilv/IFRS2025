/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Pessoa;

/**
 *
 * @author Diego
 */
public class ControladorPessoa {

    JTextField jTextFieldId;
    JTextField jTextFieldNome;
    JTextField jTextFieldNumero;
    JList<String> jList;
    JLabel jLabel;

    DefaultListModel defaultListModel;
    ArrayList<Pessoa> arrayListPessoa;
    ArrayList<String> arrayListString;

    JButton jButton;

    Pessoa pessoaEditar;

    public ControladorPessoa(JTextField jTextFieldId, JTextField jTextFieldNome, JTextField jTextFieldNumero, JList<String> jList, JLabel jLabel, JButton jButton) {
        this.jTextFieldId = jTextFieldId;
        this.jTextFieldNome = jTextFieldNome;
        this.jTextFieldNumero = jTextFieldNumero;
        this.jList = jList;
        this.jLabel = jLabel;
        this.jButton = jButton;
        arrayListPessoa = new ArrayList<>();
        defaultListModel = new DefaultListModel();
        arrayListString = new ArrayList<>();
        this.jTextFieldId.setEditable(false);
        this.jTextFieldId.setFocusable(false);
        limpar();
    }

    private int gerarId() {
        return arrayListPessoa.isEmpty() ? 0 : arrayListPessoa.getLast().getId() + 1;
    }

    private void limpar() {
        jTextFieldId.setText(String.valueOf(gerarId()));
        jTextFieldNome.setText("");
        jTextFieldNumero.setText("");
        jLabel.setText("");
    }

    private void criar() {
        Pessoa p = new Pessoa(Integer.parseInt(jTextFieldId.getText()), jTextFieldNome.getText(), jTextFieldNumero.getText());
        String msg = "Nome: " + p.getNome() + " Numero: " + p.getNumero();
        for (Pessoa po : arrayListPessoa) {
            String msg2 = "Nome: " + po.getNome() + " Numero: " + po.getNumero();
            if (msg.equals(msg2)) {
                jLabel.setText("Essa Pessoa Ja Existe!");
                return;
            }
        }
        arrayListPessoa.add(p);
        carregar();
    }

    private void carregar() {
        defaultListModel.clear();
        arrayListString.clear();
        for (Pessoa p : arrayListPessoa) {
            arrayListString.add("Nome: " + p.getNome() + " Numero: " + p.getNumero());
        }
        defaultListModel.addAll(arrayListString);
        jList.setModel(defaultListModel);
    }

    private void novoUsuario() {
        criar();
        carregar();
        limpar();
    }

    public void editar() {
        String msg = jList.getSelectedValue();
        if (msg == null || msg.isEmpty()) {
            jLabel.setText("Selecione algo na Lista!");
            return;
        }
        for (Pessoa p : arrayListPessoa) {
            String msg2 = "Nome: " + p.getNome() + " Numero: " + p.getNumero();
            if (msg.equals(msg2)) {
                pessoaEditar = p;
                jTextFieldId.setText(String.valueOf(p.getId()));
                jTextFieldNome.setText(p.getNome());
                jTextFieldNumero.setText(p.getNumero());
                jButton.setText("Editar");
                break;
            }
        }
    }

    private void alterar() {
        for (Pessoa po : arrayListPessoa) {
            String msg = "Nome: " + jTextFieldNome.getText() + " Numero: " + jTextFieldNumero.getText();
            String msg2 = "Nome: " + po.getNome() + " Numero: " + po.getNumero();
            if (msg.equals(msg2)) {
                limpar();
                jButton.setText("Criar");
                return;
            }
        }
        pessoaEditar.setNome(jTextFieldNome.getText());
        pessoaEditar.setNumero(jTextFieldNumero.getText());
        carregar();
        jButton.setText("Criar");
        limpar();
    }

    public void botao() {
        String nome = jButton.getText();
        if (nome.equals("Criar")) {
            novoUsuario();
        } else if (nome.equals("Editar")) {
            alterar();
        }
    }

}
