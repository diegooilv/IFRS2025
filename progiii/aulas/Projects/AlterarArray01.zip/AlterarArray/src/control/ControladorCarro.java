/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import java.util.Collections;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Carro;

/**
 *
 * @author Diego
 */
public final class ControladorCarro{

    JTextField jTextFieldId;
    JTextField jTextFieldModelo;
    JTextField jTextFieldMarca;
    JList<String> jList;
    
    ArrayList<String> arrayListStrings;
    ArrayList<Carro> arrayListCarro;
    
    DefaultListModel defaultListModel;

    public ControladorCarro(JTextField jTextFieldId, JTextField jTextFieldModelo, JTextField jTextFieldMarca, JList<String> jList) {
        this.jTextFieldId = jTextFieldId;
        this.jTextFieldModelo = jTextFieldModelo;
        this.jTextFieldMarca = jTextFieldMarca;
        this.jList = jList;
        arrayListStrings = new ArrayList<>();
        arrayListCarro = new ArrayList<>();
        defaultListModel = new DefaultListModel();
        this.jTextFieldId.setEditable(false);
        this.jTextFieldId.setFocusable(false);
        limpar();
    }
    
    
    
    public void limpar() {
        jTextFieldId.setText(String.valueOf(gerarId()));
        jTextFieldMarca.setText("");
        jTextFieldModelo.setText("");
    }
    
    public int gerarId() {
        return arrayListCarro.isEmpty() ? 0 : arrayListCarro.getLast().getId() + 1;        
    }                
    
    public void salvar() {
        Carro c = new Carro(Integer.parseInt(jTextFieldId.getText()), jTextFieldModelo.getText(), jTextFieldMarca.getText());
        arrayListCarro.add(c);
    }
    
    public void carregar() {
        arrayListStrings.clear();
        defaultListModel.clear();
        for (Carro co : arrayListCarro) {
            arrayListStrings.add("Modelo: " + co.getModelo() + " Marca: " + co.getMarca());
        }
        Collections.sort(arrayListStrings);
        defaultListModel.addAll(arrayListStrings);
        jList.setModel(defaultListModel);
    }
    
    public void novoUsuario() {
        salvar();
        carregar();
        limpar();
    }
    
}
