/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import java.util.Collections;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Moto;

/**
 *
 * @author Diego
 */
public final class ControladorMoto {

    JTextField jTextFieldId;
    JTextField jTextFieldModelo;
    JTextField jTextFieldMarca;
    JList<String> jList;
    
    ArrayList<String> arrayListStrings;
    ArrayList<Moto> arrayListMoto;
    
    DefaultListModel defaultListModel;
    
    public ControladorMoto(JTextField jTextFieldId, JTextField jTextFieldModelo, JTextField jTextFieldMarca, JList<String> jList) {
        this.jTextFieldId = jTextFieldId;
        this.jTextFieldModelo = jTextFieldModelo;
        this.jTextFieldMarca = jTextFieldMarca;
        this.jList = jList;
        arrayListStrings = new ArrayList<>();
        arrayListMoto = new ArrayList<>();
        defaultListModel = new DefaultListModel();
        this.jTextFieldId.setEditable(false);
        this.jTextFieldId.setFocusable(false);
        limpar();
    }
    
    public void limpar() {
        jTextFieldId.setText(String.valueOf(gerarId()));
        jTextFieldMarca.setText("");
        jTextFieldModelo.setText("");
    }
    
    public int gerarId() {
        return arrayListMoto.isEmpty() ? 0 : arrayListMoto.getLast().getId() + 1;        
    }
    
    public void salvar() {
        Moto m = new Moto(Integer.parseInt(jTextFieldId.getText()), jTextFieldModelo.getText(), jTextFieldMarca.getText());
        arrayListMoto.add(m);
    }
    
    public void carregar() {
        arrayListStrings.clear();
        defaultListModel.clear();
        for (Moto mo : arrayListMoto) {
            arrayListStrings.add("| Modelo: " + mo.getModelo() + " Marca: " + mo.getMarca() + " |");
        }
        Collections.sort(arrayListStrings);
        defaultListModel.addAll(arrayListStrings);
        jList.setModel(defaultListModel);
    }
    
    public void novoUsuario() {
        salvar();
        carregar();
        limpar();
    }
    
}
