/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.Dimension;
import javax.swing.JDesktopPane;
import view.Carro;
import view.Moto;
import view.Pessoa;

/**
 *
 * @author Diego
 */
public class ControladorView {

    JDesktopPane jDesktopPane;

    public ControladorView(JDesktopPane jDesktopPane) {
        this.jDesktopPane = jDesktopPane;
    }

    public void abrirCarro() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        Carro carro = new Carro();
        carro.setSize(size);
        carro.setLocation(0, 0);
        jDesktopPane.add(carro);
        carro.setVisible(true);

    }

    public void abrirPessoa() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        Pessoa pessoa = new Pessoa();
        pessoa.setSize(size);
        pessoa.setLocation(0, 0);
        jDesktopPane.add(pessoa);
        pessoa.setVisible(true);

    }

    public void abrirMoto() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        Moto moto = new Moto();
        moto.setSize(size);
        moto.setLocation(0, 0);
        jDesktopPane.add(moto);
        moto.setVisible(true);

    }
}
