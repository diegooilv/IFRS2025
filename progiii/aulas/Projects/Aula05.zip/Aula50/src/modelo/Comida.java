/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;



/**
 *
 * @author victorperes
 */
public class Comida {
    String sabor;
    String nome;

    public String getSabor() {
        return sabor;
    }

    public void setSabor(String sabor) {
        this.sabor = sabor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Comida(String sabor, String nome) {
        this.sabor = sabor;
        this.nome = nome;
    }
    
    public void imprimir(){
        System.out.println("===============");
        System.out.println("Nome: "+nome);
        System.out.println("Sabor: "+sabor);
        System.out.println("===============");
        
        
    }
    
    
    
}
