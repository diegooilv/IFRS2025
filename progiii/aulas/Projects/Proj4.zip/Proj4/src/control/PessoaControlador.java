/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import java.util.Collections;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Pessoa;

/**
 *
 * @author Diego
 */
public class PessoaControlador {

    //
    private Pessoa p;
    private final ArrayList<Pessoa> pessoasArrayList = new ArrayList<>();
    private final ArrayList<String> arrayListStrings = new ArrayList<>();
    //
    private final JTextField jTextFieldId;
    private final JTextField jTextFieldNome;
    private final JTextField jTextFieldCpf;
    private final JTextField jTextFieldTelefone;
    private final JList jList;
    private final DefaultListModel defaultListModel = new DefaultListModel();
    //

    public PessoaControlador(JTextField jTextFieldId, JTextField jTextFieldNome, JTextField jTextFieldCpf, JTextField jTextFieldTelefone, JList jList) {
        this.jTextFieldId = jTextFieldId;
        this.jTextFieldNome = jTextFieldNome;
        this.jTextFieldCpf = jTextFieldCpf;
        this.jTextFieldTelefone = jTextFieldTelefone;
        this.jList = jList;
    }

    public void salvar() {
        p = new Pessoa(Integer.parseInt(jTextFieldId.getText()), jTextFieldNome.getText(), jTextFieldCpf.getText(), jTextFieldTelefone.getText());
        pessoasArrayList.add(p);
    }

    public void limpar() {
        jTextFieldId.setText("");
        jTextFieldNome.setText("");
        jTextFieldCpf.setText("");
        jTextFieldTelefone.setText("");
    }

    public void mostrar() {
        defaultListModel.clear();
        arrayListStrings.clear();
        //
        for (Pessoa pe : pessoasArrayList) {
            arrayListStrings.add("| Nome: " + pe.getNome() + " | Cpf: " + pe.getCpf() + " | Telefone: " + pe.getTelefone() + " |");
        }
        Collections.sort(arrayListStrings);
        defaultListModel.addAll(arrayListStrings);
        jList.setModel(defaultListModel);
    }

}
