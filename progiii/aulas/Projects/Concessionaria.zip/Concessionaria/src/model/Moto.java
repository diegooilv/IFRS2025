/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Diego
 */
public class Moto {

    // cilindrada, fabricante, cor, ano, placa
    private int cilindrada;
    private String fabricante;
    private String cor;
    private int ano;
    private String placa;

    public Moto(int cilindrada, String fabricante, String cor, int ano, String placa) {
        this.cilindrada = cilindrada;
        this.fabricante = fabricante;
        this.cor = cor;
        this.ano = ano;
        this.placa = placa;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

}
