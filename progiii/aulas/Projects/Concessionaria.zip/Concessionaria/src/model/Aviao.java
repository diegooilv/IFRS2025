/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Diego
 */
public class Aviao {

    // prefixo, modelo, capacidade, companhia, ano
    private String prefixo;
    private String modelo;
    private String capacidade;
    private String companhia;
    private int ano;

    public Aviao(String prefixo, String modelo, String capacidade, String companhia, int ano) {
        this.prefixo = prefixo;
        this.modelo = modelo;
        this.capacidade = capacidade;
        this.companhia = companhia;
        this.ano = ano;
    }

    public String getPrefixo() {
        return prefixo;
    }

    public void setPrefixo(String prefixo) {
        this.prefixo = prefixo;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(String capacidade) {
        this.capacidade = capacidade;
    }

    public String getCompanhia() {
        return companhia;
    }

    public void setCompanhia(String companhia) {
        this.companhia = companhia;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

}
