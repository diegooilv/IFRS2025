/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Pessoa;

/**
 *
 * @author Diego
 */
public class ControladorPessoa {

    private Pessoa p;
    private ArrayList<Pessoa> arrayListPessoas;
    private ArrayList<String> arrayListStrings;
    private JList jList;
    private DefaultListModel defaultListModel;
    //
    private JTextField jTextFieldNome;
    private JTextField jTextFieldCpf;
    private JTextField jTextFieldEmail;
    private JTextField jTextFieldIdade;
    private JTextField jTextFieldCidade;

    public ControladorPessoa(JList jList, JTextField jTextFieldNome, JTextField jTextFieldCpf, JTextField jTextFieldEmail, JTextField jTextFieldIdade, JTextField jTextFieldCidade) {
        this.jList = jList;
        this.jTextFieldNome = jTextFieldNome;
        this.jTextFieldCpf = jTextFieldCpf;
        this.jTextFieldEmail = jTextFieldEmail;
        this.jTextFieldIdade = jTextFieldIdade;
        this.jTextFieldCidade = jTextFieldCidade;
        arrayListPessoas = new ArrayList<>();
        arrayListStrings = new ArrayList<>();
        defaultListModel = new DefaultListModel();
    }

    public void salvar() {
        p = new Pessoa(
                jTextFieldNome.getText(),
                jTextFieldCpf.getText(),
                jTextFieldEmail.getText(),
                Integer.parseInt(jTextFieldIdade.getText()),
                jTextFieldCidade.getText());
        arrayListPessoas.add(p);
    }

    public void limpar() {
        jTextFieldNome.setText("");
        jTextFieldCpf.setText("");
        jTextFieldEmail.setText("");
        jTextFieldIdade.setText("");
        jTextFieldCidade.setText("");
    }

    public void carregar() {
        defaultListModel.clear();
        arrayListStrings.clear();

        for (Pessoa pe : arrayListPessoas) {
            String info = String.format(
                    " | Nome: %s | CPF: %s | Email: %s | Idade: %d | Cidade: %s |",
                    pe.getNome(),
                    pe.getCpf(),
                    pe.getEmail(),
                    pe.getIdade(),
                    pe.getCidade()
            );
            arrayListStrings.add(info);
        }

        defaultListModel.addAll(arrayListStrings);
        jList.setModel(defaultListModel);
    }

}
