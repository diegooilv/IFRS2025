/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Carro;

/**
 *
 * @author Diego
 */
public class ControladorCarro {

    private Carro c;
    private ArrayList<Carro> arrayListCarros;
    private ArrayList<String> arrayListStrings;
    private JList jList;
    private DefaultListModel defaultListModel;

    private JTextField jTextFieldMarca;
    private JTextField jTextFieldModelo;
    private JTextField jTextFieldCor;
    private JTextField jTextFieldAno;
    private JTextField jTextFieldPlaca;

    public ControladorCarro(JList jList, JTextField jTextFieldMarca, JTextField jTextFieldModelo, JTextField jTextFieldCor, JTextField jTextFieldAno, JTextField jTextFieldPlaca) {
        this.jList = jList;
        this.jTextFieldMarca = jTextFieldMarca;
        this.jTextFieldModelo = jTextFieldModelo;
        this.jTextFieldCor = jTextFieldCor;
        this.jTextFieldAno = jTextFieldAno;
        this.jTextFieldPlaca = jTextFieldPlaca;
        arrayListCarros = new ArrayList<>();
        arrayListStrings = new ArrayList<>();
        defaultListModel = new DefaultListModel();
    }

    public void salvar() {
        c = new Carro(
                jTextFieldMarca.getText(),
                jTextFieldModelo.getText(),
                jTextFieldCor.getText(),
                Integer.parseInt(jTextFieldAno.getText()),
                jTextFieldPlaca.getText()
        );

        arrayListCarros.add(c);

    }

    public void limpar() {
        jTextFieldMarca.setText("");
        jTextFieldModelo.setText("");
        jTextFieldCor.setText("");
        jTextFieldAno.setText("");
        jTextFieldPlaca.setText("");
    }

    public void carregar() {
        defaultListModel.clear();
        arrayListStrings.clear();

        for (Carro ca : arrayListCarros) {
            String info = String.format(
                    " | Marca: %s | Modelo: %s | Cor: %s | Ano: %d | Placa: %s |",
                    ca.getMarca(),
                    ca.getModelo(),
                    ca.getCor(),
                    ca.getAno(),
                    ca.getPlaca()
            );
            arrayListStrings.add(info);
        }
        defaultListModel.addAll(arrayListStrings);
        jList.setModel(defaultListModel);
    }

}
