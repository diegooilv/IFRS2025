/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Moto;

/**
 *
 * @author Diego
 */
public class ControladorMoto {

    private Moto m;
    private ArrayList<Moto> arrayListMotos;
    private ArrayList<String> arrayListStrings;
    private JList jList;
    private DefaultListModel defaultListModel;

    private JTextField jTextFieldCilindrada;
    private JTextField jTextFieldFabricante;
    private JTextField jTextFieldCor;
    private JTextField jTextFieldAno;
    private JTextField jTextFieldPlaca;

    public ControladorMoto(JList jList, JTextField jTextFieldCilindrada, JTextField jTextFieldFabricante, JTextField jTextFieldCor, JTextField jTextFieldAno, JTextField jTextFieldPlaca) {
        this.jList = jList;
        this.jTextFieldCilindrada = jTextFieldCilindrada;
        this.jTextFieldFabricante = jTextFieldFabricante;
        this.jTextFieldCor = jTextFieldCor;
        this.jTextFieldAno = jTextFieldAno;
        this.jTextFieldPlaca = jTextFieldPlaca;
        arrayListMotos = new ArrayList<>();
        arrayListStrings = new ArrayList<>();
        defaultListModel = new DefaultListModel();
    }

    public void salvar() {
        m = new Moto(
                Integer.parseInt(jTextFieldCilindrada.getText()),
                jTextFieldFabricante.getText(),
                jTextFieldCor.getText(),
                Integer.parseInt(jTextFieldAno.getText()),
                jTextFieldPlaca.getText()
        );

        arrayListMotos.add(m);
    }

    public void limpar() {
        jTextFieldCilindrada.setText("");
        jTextFieldFabricante.setText("");
        jTextFieldCor.setText("");
        jTextFieldAno.setText("");
        jTextFieldPlaca.setText("");
    }

    public void carregar() {
        defaultListModel.clear();
        arrayListStrings.clear();

        for (Moto moto : arrayListMotos) {
            arrayListStrings.add(
                    " | Cilindrada: " + moto.getCilindrada()
                    + " | Fabricante: " + moto.getFabricante()
                    + " | Cor: " + moto.getCor()
                    + " | Ano: " + moto.getAno()
                    + " | Placa: " + moto.getPlaca() + " |"
            );

        }

        defaultListModel.addAll(arrayListStrings);
        jList.setModel(defaultListModel);
    }

}
