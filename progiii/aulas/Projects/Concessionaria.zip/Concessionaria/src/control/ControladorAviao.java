/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;
import model.Aviao;

/**
 *
 * @author Diego
 */
public class ControladorAviao {

    private Aviao a;
    private ArrayList<Aviao> arrayListAvioes;
    private ArrayList<String> arrayListStrings;
    private JList jList;
    private DefaultListModel defaultListModel;

    private JTextField jTextFieldPrefixo;
    private JTextField jTextFieldModelo;
    private JTextField jTextFieldCapacidade;
    private JTextField jTextFieldCompanhia;
    private JTextField jTextFieldAno;

    public ControladorAviao(JList jList, JTextField jTextFieldPrefixo, JTextField jTextFieldModelo, JTextField jTextFieldCapacidade, JTextField jTextFieldCompanhia, JTextField jTextFieldAno) {
        this.jList = jList;
        this.jTextFieldPrefixo = jTextFieldPrefixo;
        this.jTextFieldModelo = jTextFieldModelo;
        this.jTextFieldCapacidade = jTextFieldCapacidade;
        this.jTextFieldCompanhia = jTextFieldCompanhia;
        this.jTextFieldAno = jTextFieldAno;
        arrayListAvioes = new ArrayList<>();
        arrayListStrings = new ArrayList<>();
        defaultListModel = new DefaultListModel();
    }

    public void salvar() {
        a = new Aviao(
                jTextFieldPrefixo.getText(),
                jTextFieldModelo.getText(),
                jTextFieldCapacidade.getText(),
                jTextFieldCompanhia.getText(),
                Integer.parseInt(jTextFieldAno.getText())
        );

        arrayListAvioes.add(a);
    }

    public void limpar() {
        jTextFieldPrefixo.setText("");
        jTextFieldModelo.setText("");
        jTextFieldCapacidade.setText("");
        jTextFieldCompanhia.setText("");
        jTextFieldAno.setText("");
    }

    public void carregar() {
        defaultListModel.clear();
        arrayListStrings.clear();

        for (Aviao av : arrayListAvioes) {
            String info = String.format(
                    " | Prefixo: %s | Modelo: %s | Capacidade: %s | Companhia: %s | Ano: %d |",
                    av.getPrefixo(),
                    av.getModelo(),
                    av.getCapacidade(),
                    av.getCompanhia(),
                    av.getAno()
            );
            arrayListStrings.add(info);
        }
        defaultListModel.addAll(arrayListStrings);
        jList.setModel(defaultListModel);
    }

}
