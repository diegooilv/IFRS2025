/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.Dimension;
import javax.swing.JDesktopPane;
import view.Aviao;
import view.Carro;
import view.Moto;
import view.Pessoa;

/**
 *
 * @author Diego
 */
public class ControladorTela {

    private JDesktopPane jDesktopPane;

    public ControladorTela(JDesktopPane jDesktopPane) {
        this.jDesktopPane = jDesktopPane;
    }

    public void carro() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        Carro view = new Carro();
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        view.setVisible(true);
    }

    public void moto() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        Moto view = new Moto();
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        view.setVisible(true);
    }

    public void pessoa() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        Pessoa view = new Pessoa();
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        view.setVisible(true);
    }

    public void aviao() {
        jDesktopPane.removeAll();
        jDesktopPane.updateUI();
        Dimension size = jDesktopPane.getSize();
        Aviao view = new Aviao();
        view.setSize(size);
        view.setLocation(0, 0);
        jDesktopPane.add(view);
        view.setVisible(true);
    }

}
