/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.util.ArrayList;
import javax.swing.JTextField;
import model.Produto;

/**
 *
 * @author User
 */
public class ProdutoController {

    // Nome, Cor, Fabricante, Marca e Modelo
    JTextField jTextFieldNome;
    JTextField jTextFieldCor;
    JTextField jTextFieldFabricante;
    JTextField jTextFieldMarca;
    JTextField jTextFieldModelo;

    ArrayList<Produto> produtoList;

    public ProdutoController(JTextField jTextFieldNome, JTextField jTextFieldCor, JTextField jTextFieldFabricante, JTextField jTextFieldMarca, JTextField jTextFieldModelo) {
        this.jTextFieldNome = jTextFieldNome;
        this.jTextFieldCor = jTextFieldCor;
        this.jTextFieldFabricante = jTextFieldFabricante;
        this.jTextFieldMarca = jTextFieldMarca;
        this.jTextFieldModelo = jTextFieldModelo;
    

        produtoList = new ArrayList<>();
    }

    public void cadastrar() {
        Produto p = new Produto(jTextFieldNome.getText(), jTextFieldCor.getText(), jTextFieldFabricante.getText(), jTextFieldMarca.getText(), jTextFieldModelo.getText());
        produtoList.add(p);
        System.out.println("Produto Cadastrado!");
    }

    public void limpar() {
        jTextFieldNome.setText("");
        jTextFieldCor.setText("");
        jTextFieldFabricante.setText("");
        jTextFieldMarca.setText("");
        jTextFieldModelo.setText("");
    }

    public void imprimirTodos() {
        for (Produto p : produtoList) {
            p.imprimirProduto();
        }
        System.out.println("");
    }
}
