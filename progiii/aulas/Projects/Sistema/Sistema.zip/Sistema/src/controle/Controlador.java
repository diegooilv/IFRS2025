/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.util.ArrayList;
import javax.swing.JList;
import javax.swing.JTextField;
import modelo.Pessoa;

/**
 *
 * @author victorperes
 */
public class Controlador {
    
    JTextField jtextFieldID;
    JTextField jtextFieldNome;
    JTextField jtextFieldCpf;
    JList<String> jListPessoas;
    
    Pessoa pe;
    
    ArrayList<Pessoa> listaPessoas = new ArrayList<>();

    public Controlador(JTextField jtextFieldID, JTextField jtextFieldNome, JTextField jtextFieldCpf, JList<String> jListPessoas) {
        this.jtextFieldID = jtextFieldID;
        this.jtextFieldNome = jtextFieldNome;
        this.jtextFieldCpf = jtextFieldCpf;
        this.jListPessoas = jListPessoas;
    }
    
    
    
    
    
    
    
    
    
}
