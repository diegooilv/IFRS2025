/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.util.ArrayList;
import java.util.Collections;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;
import modelo.Pessoa;

/**
 *
 * @author diego
 */
public class Controlador {

    JTextField jtextFieldID;
    JTextField jtextFieldNome;
    JTextField jtextFieldCpf;
    JList<String> jListPessoas;

    Pessoa pe;

    ArrayList<Pessoa> listaPessoas = new ArrayList<>();
    ArrayList<String> listaPessoasAtualizado = new ArrayList<>();
    DefaultListModel<String> listaDePessoas = new DefaultListModel<>();

    public Controlador(JTextField jtextFieldID, JTextField jtextFieldNome, JTextField jtextFieldCpf, JList<String> jListPessoas) {
        this.jtextFieldID = jtextFieldID;
        this.jtextFieldNome = jtextFieldNome;
        this.jtextFieldCpf = jtextFieldCpf;
        this.jListPessoas = jListPessoas;
    }

    public void salvarPessoa() {
        String cpf = jtextFieldCpf.getText();
        String nome = jtextFieldNome.getText();
        int id = Integer.parseInt(jtextFieldID.getText());
        pe = new Pessoa(id, nome, cpf);
        listaPessoas.add(pe);
        atualizarLista();
    }

    public void atualizarLista() {
        listaDePessoas.clear();

        listaPessoasAtualizado = new ArrayList<>();
        for (Pessoa p : listaPessoas) {
            listaPessoasAtualizado.add("| Nome: " + p.getNome() + " | Cpf: " + p.getCpf() + " |");
        }
        Collections.sort(listaPessoasAtualizado);
        listaDePessoas.addAll(listaPessoasAtualizado);
        jListPessoas.setModel(listaDePessoas);
    }

}
